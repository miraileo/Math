#include "s21_math.h"

int s21_abs(int x) { return (int)s21_fabs(x); }